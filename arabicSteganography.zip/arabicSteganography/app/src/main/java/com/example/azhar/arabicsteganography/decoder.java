package com.example.azhar.arabicsteganography;

/**
 * Created by Azhar on 23/2/2018.
 */

import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.Scanner;

public class decoder {

    public static String decode(String str)throws Exception{
        PrintStream out = new PrintStream(System.out,true,"UTF-8");

        final Charset UTF_8 = Charset.forName("UTF-8");

        String k = "\u0640";

        LinkedList <String> moon = new LinkedList<String>();
        LinkedList <String> sun = new LinkedList<String>();
        String moon1[] ={"ب","غ","ح","ج","ك","خ","ف","ع","ق","ي","م","ه"};
        String sun1[] = {"ت","ث","س","ش","ص","ض","ط","ظ","ن","ل"};
        for(String a:moon1)moon.add(a);
        for(String a:sun1)sun.add(a);
        String bit = "";
        for(int i=0;i<str.length()-1;i++){
            if(moon.contains(str.charAt(i)+"")){
                if(str.substring(i+1,i+2).toString().equals(k)){
                    if(str.substring(i+2, i+3).toString().equals(k)){
                        bit+="11";
                    }else{
                        bit+="00";
                    }
                }
            }else if(sun.contains(str.charAt(i)+"")){
                if(str.substring(i+1,i+2).toString().equals(k)){
                    if(str.substring(i+2, i+3).toString().equals(k)){
                        bit+="10";
                    }else{
                        bit+="01";
                    }
                }
            }
        }
        return convertToString(bit);
    }
    public static String convertToString(String bit){
        String ans = "";
        for(int i=0;i<bit.length();i=i+8){
            String a = bit.substring(i, i+8);
            int b = Integer.valueOf(a, 2);
            char ch = (char)(b);
            ans+=ch;
        }
        return ans;
    }
}

