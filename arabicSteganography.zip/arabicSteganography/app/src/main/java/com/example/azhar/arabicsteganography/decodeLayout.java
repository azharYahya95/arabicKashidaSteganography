package com.example.azhar.arabicsteganography;

/**
 * Created by Azhar on 23/2/2018.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.PrintStream;
import java.nio.charset.Charset;

public class decodeLayout extends AppCompatActivity{
    private EditText dct;
    private Button dcb;
    private TextView dcv;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.decode_layout);

        dct = (EditText) findViewById(R.id.decodeText);
        dcb = (Button) findViewById(R.id.decodeBtn);
        dcv = (TextView) findViewById(R.id.decodeResult);

        dcb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    PrintStream out = new PrintStream(System.out,true,"UTF-8");

                    final Charset UTF_8 = Charset.forName("UTF-8");
                    String a = dct.getText().toString();
                    String ans = decoder.decode(a);
                    dcv.setText(ans);
                }catch (Exception e){
                    dcv.setText(e+"");
                }
            }
        });

    }
}