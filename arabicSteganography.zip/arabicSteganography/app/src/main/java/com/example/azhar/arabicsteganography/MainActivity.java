package com.example.azhar.arabicsteganography;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button enc;
    private Button dec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enc = (Button)findViewById(R.id.encBtn);
        dec = (Button)findViewById(R.id.decBtn);

    }
    public void toEncode(View view){
        Intent itt = new Intent(MainActivity.this,encodeLayout.class);
        startActivity(itt);
    }
    public void toDecode(View view){
        Intent itt = new Intent(MainActivity.this, decodeLayout.class);
        startActivity(itt);
    }
}
