package com.example.azhar.arabicsteganography;

/**
 * Created by Azhar on 23/2/2018.
 */

import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.Scanner;

public class kashida {
    public static void kashida1(String stra, String strb) throws  Exception{
        PrintStream out = new PrintStream(System.out,true,"UTF-8");

        final Charset UTF_8 = Charset.forName("UTF-8");

        String k = "\u0640";
        //Scanner in = new Scanner(System.in);
        //System.out.print("Arabic Text: ");
        String test = strb;
        StringBuffer myString = new StringBuffer(test);
        //System.out.println();
        //System.out.print("Embedded text");
        String embed = stra;

        LinkedList <String> moon = new LinkedList<String>();
        LinkedList <String> sun = new LinkedList<String>();
        String moon1[] ={"ب","غ","ح","ج","ك","خ","ف","ع","ق","ي","م","ه"};
        String sun1[] = {"ت","ث","س","ش","ص","ض","ط","ظ","ن","ل"};
        for(String a:moon1)moon.add(a);
        for(String a:sun1)sun.add(a);
        myString = encode(myString,embed);
        System.out.println(myString);

        String bb = decode(myString,moon,sun,k);
        System.out.println(bb);
    }
    public static StringBuffer encode(StringBuffer myString, String embed)throws  Exception{
        PrintStream out = new PrintStream(System.out,true,"UTF-8");

        final Charset UTF_8 = Charset.forName("UTF-8");
        String k = "\u0640";
        LinkedList <String> moon = new LinkedList<String>();
        LinkedList <String> sun = new LinkedList<String>();
        String moon1[] ={"ب","غ","ح","ج","ك","خ","ف","ع","ق","ي","م","ه"};
        String sun1[] = {"ت","ث","س","ش","ص","ض","ط","ظ","ن","ل"};
        byte b [] = embed.getBytes();
        String bit_sum = "";
        for(int i=0;i<b.length;i++){
            String bin = Integer.toBinaryString(b[i]);
            if(bin.length()<8){
                int bal = 8 - bin.length();
                int j=0;
                while(j!=bal){
                    bin = "0"+bin;
                    j++;
                }
            }
            bit_sum +=bin;
        }
        //System.out.println(bit_sum);
        //myString.insert(14, k);

        //System.out.println(myString);


        int p=0;
        for(int i=0;i<bit_sum.length();i++){
            String bits = bit_sum.substring(i, i+2).toString();

            if(bits.equals("00")){
                int j = p;
                while(j<myString.length()){
                    if(moon.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k);
                p = j+1;
            }else if(bits.equals("11")){
                int j = p;
                while(j<myString.length()){
                    if(moon.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k+""+k);
                p = j+2;

            }else if(bits.equals("01")){
                int j = p;
                while(j<myString.length()){
                    if(sun.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k);
                p = j+1;

            }else if(bits.equals("10")){
                int j = p;
                while(j<myString.length()){
                    if(sun.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k+""+k);
                p = j+2;
            }
            i++;
            //System.out.println(bits);
        }
        return myString;
    }
    public static String decode(StringBuffer str,LinkedList<String> moon, LinkedList<String> sun,String k){
        String bit = "";
        for(int i=0;i<str.length()-1;i++){
            if(moon.contains(str.charAt(i)+"")){
                if(str.substring(i+1,i+2).toString().equals(k)){
                    if(str.substring(i+2, i+3).toString().equals(k)){
                        bit+="11";
                    }else{
                        bit+="00";
                    }
                }
            }else if(sun.contains(str.charAt(i)+"")){
                if(str.substring(i+1,i+2).toString().equals(k)){
                    if(str.substring(i+2, i+3).toString().equals(k)){
                        bit+="10";
                    }else{
                        bit+="01";
                    }
                }
            }
        }
        return convertToString(bit);
    }
    public static String convertToString(String bit){
        String ans = "";
        for(int i=0;i<bit.length();i=i+8){
            String a = bit.substring(i, i+8);
            int b = Integer.valueOf(a, 2);
            char ch = (char)(b);
            ans+=ch;
        }
        return ans;
    }
}

