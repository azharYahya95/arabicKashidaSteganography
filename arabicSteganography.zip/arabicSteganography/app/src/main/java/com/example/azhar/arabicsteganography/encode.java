package com.example.azhar.arabicsteganography;

/**
 * Created by Azhar on 23/2/2018.
 */

import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.Scanner;

public class encode {
    public static String main(String a1, String a2) throws Exception{
        PrintStream out = new PrintStream(System.out,true,"UTF-8");

        final Charset UTF_8 = Charset.forName("UTF-8");

        String k = "\u0640";
        Scanner in = new Scanner(System.in);
        StringBuffer myString = new StringBuffer(a2);

        LinkedList<String> moon = new LinkedList<String>();
        LinkedList <String> sun = new LinkedList<String>();
        String moon1[] ={"ب","غ","ح","ج","ك","خ","ف","ع","ق","ي","م","ه"};
        String sun1[] = {"ت","ث","س","ش","ص","ض","ط","ظ","ن","ل"};
        for(String a:moon1)moon.add(a);
        for(String a:sun1)sun.add(a);
        byte b [] = a1.getBytes();
        String bit_sum = "";
        for(int i=0;i<b.length;i++){
            String bin = Integer.toBinaryString(b[i]);
            if(bin.length()<8){
                int bal = 8 - bin.length();
                int j=0;
                while(j!=bal){
                    bin = "0"+bin;
                    j++;
                }
            }
            bit_sum +=bin;
        }
        //System.out.println(bit_sum);
        //myString.insert(14, k);

        //System.out.println(myString);


        int p=0;
        for(int i=0;i<bit_sum.length();i++){
            String bits = bit_sum.substring(i, i+2).toString();

            if(bits.equals("00")){
                int j = p;
                while(j<myString.length()){
                    if(moon.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k);
                p = j+1;
            }else if(bits.equals("11")){
                int j = p;
                while(j<myString.length()){
                    if(moon.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k+""+k);
                p = j+2;

            }else if(bits.equals("01")){
                int j = p;
                while(j<myString.length()){
                    if(sun.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k);
                p = j+1;

            }else if(bits.equals("10")){
                int j = p;
                while(j<myString.length()){
                    if(sun.contains(myString.charAt(j)+"")){
                        if(myString.charAt(j+1)!=' '){
                            break;
                        }
                    }
                    j++;
                }
                myString.insert(j+1, k+""+k);
                p = j+2;
            }
            i++;
            //System.out.println(bits);
        }
       return myString.toString();


    }
}

